Team Name : Team Fragile
Institution name : Jagannath University

Email List : 
1st participant : nazmos789@gmail.com
2nd participant : niloyp10@gmail.com
3rd participant :  alauddinajad13@gmail.com